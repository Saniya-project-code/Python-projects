from flask_sqlalchemy import SQLAlchemy
from flask import current_app
import os

db = SQLAlchemy()

def init_db():
    """Initialize the database connection."""
    from flask import current_app
    
    # Configure SQLAlchemy
    database_url = os.getenv('DATABASE_URL')
    if not database_url:
        # Default to SQLite for development
        database_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'resumes.db')
        database_url = f"sqlite:///{database_path}"
    
    current_app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    current_app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(current_app)
    
    # Create tables
    with current_app.app_context():
        # Import models to ensure they're registered with SQLAlchemy
        from database.models import Resume
        
        # Create tables
        db.create_all()