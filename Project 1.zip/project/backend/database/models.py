from database.db import db
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy import DateTime, func
import uuid
from datetime import datetime
import json

class Resume(db.Model):
    """Resume model for storing parsed resume data."""
    
    __tablename__ = 'resumes'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(50), nullable=True)
    location = db.Column(db.String(255), nullable=True)
    
    # Using JSONB for PostgreSQL, falling back to Text for SQLite
    _skills = db.Column(db.Text, nullable=True)
    _education = db.Column(db.Text, nullable=True)
    _experience = db.Column(db.Text, nullable=True)
    
    raw_text = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @property
    def skills(self):
        """Get skills as a Python list."""
        if not self._skills:
            return []
        return json.loads(self._skills)
    
    @skills.setter
    def skills(self, value):
        """Store skills as JSON string."""
        self._skills = json.dumps(value) if value else None
    
    @property
    def education(self):
        """Get education as a Python list of dicts."""
        if not self._education:
            return []
        return json.loads(self._education)
    
    @education.setter
    def education(self, value):
        """Store education as JSON string."""
        self._education = json.dumps(value) if value else None
    
    @property
    def experience(self):
        """Get experience as a Python list of dicts."""
        if not self._experience:
            return []
        return json.loads(self._experience)
    
    @experience.setter
    def experience(self, value):
        """Store experience as JSON string."""
        self._experience = json.dumps(value) if value else None
    
    def __repr__(self):
        return f"<Resume {self.name} ({self.email})>"