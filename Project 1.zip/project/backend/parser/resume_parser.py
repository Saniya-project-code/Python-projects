import spacy
import pdfplumber
import re
import logging
from typing import Dict, List, Any, Optional
from docx import Document

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load the spaCy model
try:
    nlp = spacy.load("en_core_web_lg")
except Exception as e:
    logger.error(f"Error loading spaCy model: {str(e)}")
    logger.warning("Defaulting to en_core_web_sm. For better results, install en_core_web_lg.")
    try:
        nlp = spacy.load("en_core_web_sm")
    except Exception as e:
        logger.error(f"Error loading fallback spaCy model: {str(e)}")
        nlp = None

def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract text from a PDF file."""
    try:
        text = ""
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""
        return text
    except Exception as e:
        logger.error(f"Error extracting text from PDF {pdf_path}: {str(e)}")
        return ""

def extract_text_from_docx(docx_path: str) -> str:
    """Extract text from a DOCX file."""
    try:
        doc = Document(docx_path)
        return "\n".join([paragraph.text for paragraph in doc.paragraphs])
    except Exception as e:
        logger.error(f"Error extracting text from DOCX {docx_path}: {str(e)}")
        return ""

def extract_text(file_path: str) -> str:
    """Extract text from a resume file based on file extension."""
    if file_path.endswith('.pdf'):
        return extract_text_from_pdf(file_path)
    elif file_path.endswith('.docx'):
        return extract_text_from_docx(file_path)
    elif file_path.endswith('.doc'):
        logger.warning(f"DOC format requires additional libraries. Converting to text may not be perfect.")
        # This would require additional libraries like antiword or textract in a real implementation
        return "DOC extraction not implemented in this demo."
    else:
        return ""

def extract_name(text: str, doc) -> str:
    """Extract candidate name from text."""
    # Simple approach: Get the first PERSON entity
    if doc and doc.ents:
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                return ent.text
    
    # Fallback: Try to find a name pattern at the beginning of the resume
    # (This is a simplified approach and would be more robust in a real implementation)
    lines = text.split('\n')
    for i in range(min(5, len(lines))):  # Check first 5 lines
        line = lines[i].strip()
        if line and len(line) < 40 and not any(keyword in line.lower() for keyword in ['resume', 'curriculum', 'vitae', 'cv']):
            return line
    
    return "Unknown"

def extract_contact_info(text: str, doc) -> Dict[str, str]:
    """Extract contact information like email, phone, and location."""
    contact_info = {
        "email": "",
        "phone": "",
        "location": ""
    }
    
    # Extract email
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    email_matches = re.findall(email_pattern, text)
    if email_matches:
        contact_info["email"] = email_matches[0]
    
    # Extract phone
    phone_pattern = r'\b(?:\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b'
    phone_matches = re.findall(phone_pattern, text)
    if phone_matches:
        contact_info["phone"] = phone_matches[0]
    
    # Extract location (simplified approach)
    if doc and doc.ents:
        locations = [ent.text for ent in doc.ents if ent.label_ in ["GPE", "LOC"]]
        if locations:
            contact_info["location"] = ", ".join(locations[:2])
    
    return contact_info

def extract_skills(text: str, doc) -> List[str]:
    """Extract skills from text."""
    # This is a simplified approach. In a real implementation, you would:
    # 1. Use a comprehensive skills database
    # 2. Apply more sophisticated NLP techniques
    # 3. Consider context to avoid false positives
    
    common_skills = [
        "python", "javascript", "typescript", "java", "c++", "c#", "ruby",
        "php", "swift", "kotlin", "golang", "rust", "sql", "nosql", "mongodb",
        "postgresql", "mysql", "oracle", "dynamodb", "react", "angular", "vue",
        "node.js", "express", "django", "flask", "spring", "aspnet", "redux",
        "aws", "azure", "gcp", "docker", "kubernetes", "jenkins", "git",
        "ci/cd", "agile", "scrum", "devops", "machine learning", "data science",
        "tensorflow", "pytorch", "pandas", "numpy", "scikit-learn", "nlp",
        "computer vision", "deep learning", "ai", "blockchain", "project management"
    ]
    
    skills = set()
    
    # Look for common skills in the text
    for skill in common_skills:
        if re.search(r'\b' + re.escape(skill) + r'\b', text.lower()):
            # Normalize skill name (capitalize appropriately)
            if skill.lower() in ['aws', 'gcp', 'php', 'nlp', 'ai', 'ci/cd', 'sql', 'nosql']:
                skills.add(skill.upper())
            elif skill.lower() == 'javascript':
                skills.add('JavaScript')
            elif skill.lower() == 'typescript':
                skills.add('TypeScript')
            elif skill.lower() == 'python':
                skills.add('Python')
            elif skill.lower() == 'java':
                skills.add('Java')
            elif '.' in skill:  # e.g., node.js
                skills.add(skill.replace('.', '.').title())
            else:
                skills.add(skill.title())
    
    return sorted(list(skills))

def extract_education(text: str, doc) -> List[Dict[str, str]]:
    """Extract education information."""
    education = []
    
    # Look for education sections
    education_keywords = ['education', 'academic background', 'qualification', 'degree']
    degree_patterns = [
        r'\b(?:Bachelor|Master|PhD|Doctorate|B\.S\.|M\.S\.|B\.A\.|M\.A\.|B\.Eng\.|M\.Eng\.|MBA|Associate)\b'
    ]
    
    # Split text into sections (simplified)
    sections = re.split(r'\n\s*\n', text)
    
    for section in sections:
        # Check if this might be an education section
        if any(keyword in section.lower() for keyword in education_keywords) or re.search('|'.join(degree_patterns), section, re.IGNORECASE):
            lines = section.split('\n')
            
            degree = ""
            institution = ""
            year = ""
            
            # Look for degree information
            for line in lines:
                # Try to extract degree
                if not degree:
                    degree_match = re.search('|'.join(degree_patterns), line, re.IGNORECASE)
                    if degree_match:
                        degree = line.strip()
                
                # Try to extract institution
                if not institution and 'university' in line.lower() or 'college' in line.lower() or 'institute' in line.lower() or 'school' in line.lower():
                    institution = line.strip()
                
                # Try to extract year
                year_match = re.search(r'\b(19|20)\d{2}\s*(-|–|to)\s*(19|20)\d{2}|\b(19|20)\d{2}\b', line)
                if year_match and not year:
                    year = year_match.group(0)
            
            if degree or institution:
                education.append({
                    "degree": degree,
                    "institution": institution,
                    "year": year
                })
    
    # If no education was extracted, try a simpler approach
    if not education and doc:
        for ent in doc.ents:
            if ent.label_ == "ORG" and ('university' in ent.text.lower() or 'college' in ent.text.lower()):
                education.append({
                    "degree": "Degree",
                    "institution": ent.text,
                    "year": ""
                })
    
    return education

def extract_experience(text: str, doc) -> List[Dict[str, str]]:
    """Extract work experience information."""
    experience = []
    
    # Look for experience sections
    experience_keywords = ['experience', 'employment', 'work history', 'professional background']
    
    # Split text into sections (simplified)
    sections = re.split(r'\n\s*\n', text)
    
    in_experience_section = False
    current_job = {}
    
    for section in sections:
        # Check if this is an experience section header
        if any(keyword in section.lower() for keyword in experience_keywords):
            in_experience_section = True
            continue
        
        # If we're in an experience section, try to parse job details
        if in_experience_section:
            lines = section.split('\n')
            
            # If the section starts with what looks like a job title/company
            if len(lines) > 1 and not lines[0].strip().lower().startswith(('skill', 'education', 'reference')):
                
                # Try to extract job title and company
                title_company = lines[0].strip()
                
                # Try to extract duration
                duration = ""
                for line in lines[1:3]:  # Check the next couple of lines for dates
                    date_match = re.search(r'\b(19|20)\d{2}\s*(-|–|to)\s*(19|20)\d{2}|\b(19|20)\d{2}\s*(-|–|to)\s*Present\b', line, re.IGNORECASE)
                    if date_match:
                        duration = date_match.group(0)
                        break
                
                # Try to separate title and company
                title = title_company
                company = ""
                
                # If there's a common separator like at, with, for
                for separator in [' at ', ' with ', ' for ', ' - ', '|', ',']:
                    if separator in title_company:
                        parts = title_company.split(separator, 1)
                        title = parts[0].strip()
                        company = parts[1].strip()
                        break
                
                # Get description from remaining lines
                description = "\n".join(lines[1:]).strip()
                
                if title and (company or duration):
                    experience.append({
                        "title": title,
                        "company": company,
                        "duration": duration,
                        "description": description
                    })
    
    # If no experience was extracted using the section approach, try entity-based approach
    if not experience and doc:
        org_spans = [doc[ent.start:ent.end] for ent in doc.ents if ent.label_ == "ORG"]
        for org_span in org_spans:
            # Look for dates in the vicinity of the organization
            context_start = max(0, org_span.start - 10)
            context_end = min(len(doc), org_span.end + 10)
            context = doc[context_start:context_end].text
            
            date_match = re.search(r'\b(19|20)\d{2}\s*(-|–|to)\s*(19|20)\d{2}|\b(19|20)\d{2}\s*(-|–|to)\s*Present\b', context, re.IGNORECASE)
            duration = date_match.group(0) if date_match else ""
            
            experience.append({
                "title": "Position",
                "company": org_span.text,
                "duration": duration,
                "description": "Worked at this organization."
            })
    
    return experience

def parse_resume(file_path: str) -> Dict[str, Any]:
    """Parse a resume file and extract structured information."""
    logger.info(f"Parsing resume: {file_path}")
    
    # Extract text from the resume
    text = extract_text(file_path)
    
    if not text:
        logger.error(f"Could not extract text from {file_path}")
        return {"error": "Could not extract text from the file"}
    
    # Process text with spaCy
    doc = nlp(text) if nlp else None
    
    # Extract information
    name = extract_name(text, doc)
    contact_info = extract_contact_info(text, doc)
    skills = extract_skills(text, doc)
    education = extract_education(text, doc)
    experience = extract_experience(text, doc)
    
    # Construct the parsed resume
    parsed_resume = {
        "name": name,
        "email": contact_info["email"],
        "phone": contact_info["phone"],
        "location": contact_info["location"],
        "skills": skills,
        "education": education,
        "experience": experience,
        "raw_text": text
    }
    
    logger.info(f"Successfully parsed resume for: {name}")
    return parsed_resume

if __name__ == "__main__":
    # Test the parser with a sample resume
    import sys
    if len(sys.argv) > 1:
        result = parse_resume(sys.argv[1])
        import json
        print(json.dumps(result, indent=2))
    else:
        print("Please provide a resume file path")