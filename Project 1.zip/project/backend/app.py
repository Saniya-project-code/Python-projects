from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from api.routes import api_bp
from database.db import init_db

app = Flask(__name__)
CORS(app)

# Load configuration
if os.path.exists('.env'):
    from dotenv import load_dotenv
    load_dotenv()

app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB max upload

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize database
init_db()

# Register blueprints
app.register_blueprint(api_bp, url_prefix='/api')

@app.route('/')
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "ok", "message": "Resume Parser API is running"})

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def server_error(error):
    return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_ENV', 'production') == 'development'
    
    app.run(host=host, port=port, debug=debug)