from flask import Blueprint, request, jsonify, current_app
import os
import uuid
from werkzeug.utils import secure_filename
from parser.resume_parser import parse_resume
from database.models import Resume, db

api_bp = Blueprint('api', __name__)

ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@api_bp.route('/parse', methods=['POST'])
def upload_resume():
    """Upload and parse a resume file"""
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    if not allowed_file(file.filename):
        return jsonify({"error": f"File type not allowed. Please upload: {', '.join(ALLOWED_EXTENSIONS)}"}), 400
    
    try:
        # Generate a unique filename
        filename = str(uuid.uuid4()) + '_' + secure_filename(file.filename)
        file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        # Parse the resume
        parsed_data = parse_resume(file_path)
        
        # Store in database
        resume = Resume(
            name=parsed_data.get('name', 'Unknown'),
            email=parsed_data.get('email', ''),
            phone=parsed_data.get('phone', ''),
            location=parsed_data.get('location', ''),
            skills=parsed_data.get('skills', []),
            education=parsed_data.get('education', []),
            experience=parsed_data.get('experience', []),
            raw_text=parsed_data.get('raw_text', ''),
            file_path=file_path
        )
        db.session.add(resume)
        db.session.commit()
        
        # Return the parsed data
        return jsonify({
            "id": resume.id,
            "name": resume.name,
            "email": resume.email,
            "phone": resume.phone,
            "location": resume.location,
            "skills": resume.skills,
            "education": resume.education,
            "experience": resume.experience,
            "parsed_date": resume.created_at.isoformat()
        })
        
    except Exception as e:
        return jsonify({"error": f"Failed to process resume: {str(e)}"}), 500

@api_bp.route('/resumes', methods=['GET'])
def get_resumes():
    """Get all parsed resumes"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    resumes_query = Resume.query
    
    # Filter by skills if provided
    skills = request.args.get('skills')
    if skills:
        skills_list = skills.split(',')
        for skill in skills_list:
            resumes_query = resumes_query.filter(Resume.skills.contains(skill.strip()))
    
    # Search by name or email
    search = request.args.get('search')
    if search:
        search_term = f"%{search}%"
        resumes_query = resumes_query.filter(
            (Resume.name.ilike(search_term)) | 
            (Resume.email.ilike(search_term))
        )
    
    # Pagination
    pagination = resumes_query.order_by(Resume.created_at.desc()).paginate(
        page=page, per_page=per_page
    )
    
    resumes = [{
        "id": resume.id,
        "name": resume.name,
        "email": resume.email,
        "phone": resume.phone,
        "location": resume.location,
        "skills": resume.skills,
        "parsed_date": resume.created_at.isoformat()
    } for resume in pagination.items]
    
    return jsonify({
        "resumes": resumes,
        "total": pagination.total,
        "pages": pagination.pages,
        "page": page,
        "per_page": per_page
    })

@api_bp.route('/resumes/<resume_id>', methods=['GET'])
def get_resume(resume_id):
    """Get a specific resume by ID"""
    resume = Resume.query.get(resume_id)
    
    if not resume:
        return jsonify({"error": "Resume not found"}), 404
    
    return jsonify({
        "id": resume.id,
        "name": resume.name,
        "email": resume.email,
        "phone": resume.phone,
        "location": resume.location,
        "skills": resume.skills,
        "education": resume.education,
        "experience": resume.experience,
        "raw_text": resume.raw_text,
        "parsed_date": resume.created_at.isoformat()
    })

@api_bp.route('/resumes/<resume_id>', methods=['DELETE'])
def delete_resume(resume_id):
    """Delete a resume by ID"""
    resume = Resume.query.get(resume_id)
    
    if not resume:
        return jsonify({"error": "Resume not found"}), 404
    
    # Delete the associated file
    if resume.file_path and os.path.exists(resume.file_path):
        try:
            os.remove(resume.file_path)
        except Exception as e:
            current_app.logger.error(f"Error deleting file {resume.file_path}: {str(e)}")
    
    # Delete from database
    db.session.delete(resume)
    db.session.commit()
    
    return jsonify({"message": "Resume deleted successfully"})

@api_bp.route('/stats', methods=['GET'])
def get_stats():
    """Get resume parsing statistics"""
    total_resumes = Resume.query.count()
    
    # Count resumes parsed today
    from datetime import datetime, time
    today_start = datetime.combine(datetime.today(), time.min)
    today_end = datetime.combine(datetime.today(), time.max)
    parsed_today = Resume.query.filter(
        Resume.created_at.between(today_start, today_end)
    ).count()
    
    # Get unique candidates (by email)
    total_candidates = db.session.query(Resume.email).distinct().count()
    
    return jsonify({
        "total_resumes": total_resumes,
        "parsed_today": parsed_today,
        "total_candidates": total_candidates
    })

@api_bp.route('/download/<resume_id>', methods=['GET'])
def download_resume(resume_id):
    """Download the original resume file"""
    resume = Resume.query.get(resume_id)
    
    if not resume or not resume.file_path:
        return jsonify({"error": "File not found"}), 404
    
    if not os.path.exists(resume.file_path):
        return jsonify({"error": "File not found on server"}), 404
    
    from flask import send_file
    return send_file(resume.file_path, as_attachment=True)