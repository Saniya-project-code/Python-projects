import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface SkillsDistributionProps {
  loading?: boolean;
}

const SkillsDistribution: React.FC<SkillsDistributionProps> = ({ loading = false }) => {
  // Mock data
  const data = {
    labels: ['JavaScript', 'Python', 'Java', 'React', 'Node.js', 'SQL'],
    datasets: [
      {
        label: 'Number of candidates',
        data: [65, 59, 45, 81, 56, 55],
        backgroundColor: [
          'rgba(59, 130, 246, 0.7)', // primary-500
          'rgba(13, 148, 136, 0.7)', // secondary-600
          'rgba(245, 158, 11, 0.7)', // accent-500
          'rgba(16, 185, 129, 0.7)', // success
          'rgba(249, 115, 22, 0.7)', // warning
          'rgba(239, 68, 68, 0.7)',  // error
        ],
        borderColor: [
          'rgb(37, 99, 235)', // primary-600
          'rgb(5, 150, 105)', // secondary-700
          'rgb(217, 119, 6)', // accent-600
          'rgb(4, 120, 87)',  // success darker
          'rgb(234, 88, 12)', // warning darker
          'rgb(220, 38, 38)', // error darker
        ],
        borderWidth: 1,
      },
    ],
  };

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(17, 24, 39, 0.8)',
        padding: 12,
        titleFont: {
          size: 14,
          weight: 'bold',
        },
        bodyFont: {
          size: 13,
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
        grid: {
          drawBorder: false,
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  if (loading) {
    return (
      <div className="h-64 flex items-center justify-center bg-neutral-50 rounded-md">
        <div className="w-12 h-12 rounded-full border-4 border-primary-200 border-t-primary-600 animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="h-64">
      <Bar data={data} options={options} />
    </div>
  );
};

export default SkillsDistribution;