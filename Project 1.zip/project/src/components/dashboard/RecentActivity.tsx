import { Clock } from 'lucide-react';

interface Activity {
  id: number;
  type: 'upload' | 'parse' | 'search' | 'export';
  description: string;
  timestamp: string;
}

interface RecentActivityProps {
  activities: Activity[];
  loading?: boolean;
}

const RecentActivity: React.FC<RecentActivityProps> = ({ 
  activities,
  loading = false 
}) => {
  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'upload':
        return <div className="p-1 rounded-full bg-primary-100 text-primary-600">📄</div>;
      case 'parse':
        return <div className="p-1 rounded-full bg-secondary-100 text-secondary-600">🔍</div>;
      case 'search':
        return <div className="p-1 rounded-full bg-accent-100 text-accent-600">🔎</div>;
      case 'export':
        return <div className="p-1 rounded-full bg-success-100 text-success-600">📊</div>;
      default:
        return <div className="p-1 rounded-full bg-neutral-100 text-neutral-600">📝</div>;
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="flex items-start gap-3 animate-pulse">
            <div className="rounded-full bg-neutral-200 h-8 w-8"></div>
            <div className="flex-1">
              <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-neutral-200 rounded w-1/4"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div className="text-center py-8 text-neutral-500">
        <p>No recent activity found.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {activities.map(activity => (
        <div key={activity.id} className="flex items-start gap-3">
          {getActivityIcon(activity.type)}
          <div className="flex-1">
            <p className="text-sm text-neutral-700">{activity.description}</p>
            <p className="text-xs text-neutral-500 flex items-center mt-1">
              <Clock className="h-3 w-3 mr-1" />
              {activity.timestamp}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RecentActivity;