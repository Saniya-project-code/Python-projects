import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: number;
  loading?: boolean;
}

const StatsCard: React.FC<StatsCardProps> = ({ 
  title, 
  value, 
  icon,
  trend,
  loading = false
}) => {
  const isTrendPositive = trend && trend > 0;
  const trendFormatted = trend ? Math.abs(trend) : 0;

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 border border-neutral-200 transition-all duration-200 hover:shadow-md">
      {loading ? (
        <>
          <div className="h-6 w-24 bg-neutral-200 rounded animate-pulse mb-2"></div>
          <div className="h-8 w-16 bg-neutral-200 rounded animate-pulse mb-2"></div>
          <div className="h-4 w-32 bg-neutral-200 rounded animate-pulse"></div>
        </>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-neutral-500">{title}</h3>
            <div className="p-2 rounded-full bg-neutral-100">{icon}</div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold text-neutral-900">{value}</div>
            {trend !== undefined && (
              <p className={`text-sm flex items-center mt-1 ${isTrendPositive ? 'text-success-600' : 'text-error-600'}`}>
                {isTrendPositive ? (
                  <TrendingUp className="h-4 w-4 mr-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 mr-1" />
                )}
                <span>{trendFormatted}% {isTrendPositive ? 'increase' : 'decrease'}</span>
              </p>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default StatsCard;