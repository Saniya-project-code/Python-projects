import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  ChartOptions
} from 'chart.js';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend);

interface EducationLevelsProps {
  loading?: boolean;
}

const EducationLevels: React.FC<EducationLevelsProps> = ({ loading = false }) => {
  // Mock data
  const data = {
    labels: ["Bachelor's", "Master's", "PhD", "Associate", "High School"],
    datasets: [
      {
        data: [42, 28, 10, 15, 5],
        backgroundColor: [
          'rgba(59, 130, 246, 0.7)', // primary-500
          'rgba(13, 148, 136, 0.7)', // secondary-600
          'rgba(245, 158, 11, 0.7)', // accent-500
          'rgba(16, 185, 129, 0.7)', // success
          'rgba(239, 68, 68, 0.7)',  // error
        ],
        borderColor: [
          'rgb(37, 99, 235)', // primary-600
          'rgb(5, 150, 105)', // secondary-700
          'rgb(217, 119, 6)', // accent-600
          'rgb(4, 120, 87)',  // success darker
          'rgb(220, 38, 38)', // error darker
        ],
        borderWidth: 1,
      },
    ],
  };

  const options: ChartOptions<'doughnut'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          boxWidth: 12,
          padding: 15,
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        backgroundColor: 'rgba(17, 24, 39, 0.8)',
        padding: 12,
        titleFont: {
          size: 14,
          weight: 'bold',
        },
        bodyFont: {
          size: 13,
        },
      },
    },
    cutout: '65%',
  };

  if (loading) {
    return (
      <div className="h-64 flex items-center justify-center bg-neutral-50 rounded-md">
        <div className="w-12 h-12 rounded-full border-4 border-secondary-200 border-t-secondary-600 animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="h-64">
      <Doughnut data={data} options={options} />
    </div>
  );
};

export default EducationLevels;