import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Upload, 
  Files, 
  Settings, 
  ChevronLeft, 
  ChevronRight,
  FileText
} from 'lucide-react';

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  return (
    <aside 
      className={`bg-primary-800 text-white transition-all duration-300 ease-in-out flex flex-col ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Logo */}
      <div className="p-4 flex items-center justify-between border-b border-primary-700">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <FileText className="h-8 w-8 text-primary-300" />
            <span className="text-xl font-bold">ResumeAI</span>
          </div>
        )}
        {collapsed && <FileText className="h-8 w-8 mx-auto text-primary-300" />}
        <button 
          onClick={toggleSidebar}
          className="p-1 rounded-full hover:bg-primary-700 transition-colors"
        >
          {collapsed ? (
            <ChevronRight size={20} />
          ) : (
            <ChevronLeft size={20} />
          )}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4">
        <ul className="space-y-1">
          <NavItem 
            to="/" 
            icon={<LayoutDashboard size={20} />} 
            label="Dashboard" 
            collapsed={collapsed} 
          />
          <NavItem 
            to="/upload" 
            icon={<Upload size={20} />} 
            label="Upload" 
            collapsed={collapsed} 
          />
          <NavItem 
            to="/resumes" 
            icon={<Files size={20} />} 
            label="Resumes" 
            collapsed={collapsed} 
          />
          <NavItem 
            to="/settings" 
            icon={<Settings size={20} />} 
            label="Settings" 
            collapsed={collapsed} 
          />
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-primary-700">
        {!collapsed && (
          <div className="text-xs text-primary-300">
            <p>ResumeAI Parser</p>
            <p>v0.1.0</p>
          </div>
        )}
      </div>
    </aside>
  );
};

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  collapsed: boolean;
}

const NavItem: React.FC<NavItemProps> = ({ to, icon, label, collapsed }) => {
  return (
    <li>
      <NavLink 
        to={to} 
        className={({ isActive }) => 
          `flex items-center px-4 py-2 ${
            isActive ? 'bg-primary-700 text-white' : 'text-primary-200 hover:bg-primary-700 hover:text-white'
          } transition-colors rounded-lg ${collapsed ? 'justify-center' : 'space-x-3'}`
        }
      >
        {icon}
        {!collapsed && <span>{label}</span>}
      </NavLink>
    </li>
  );
};

export default Sidebar;