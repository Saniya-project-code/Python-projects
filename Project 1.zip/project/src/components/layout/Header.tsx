import { Bell, Search, User } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-white border-b border-neutral-200 px-4 py-3 flex items-center justify-between">
      <div className="flex-1">
        <div className="relative max-w-md">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-5 w-5 text-neutral-400" />
          </div>
          <input
            type="search"
            className="block w-full p-2 pl-10 text-sm border border-neutral-300 rounded-lg bg-neutral-50 focus:ring-primary-500 focus:border-primary-500"
            placeholder="Search resumes, skills, candidates..."
          />
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <button className="p-2 rounded-lg hover:bg-neutral-100 relative">
          <Bell className="h-5 w-5 text-neutral-600" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-primary-600 rounded-full"></span>
        </button>

        <div className="flex items-center space-x-2">
          <div className="w-9 h-9 rounded-full bg-primary-700 text-white flex items-center justify-center">
            <User className="h-5 w-5" />
          </div>
          <div className="hidden md:block text-sm">
            <div className="font-medium text-neutral-900">Admin User</div>
            <div className="text-xs text-neutral-500">admin@example.com</div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;