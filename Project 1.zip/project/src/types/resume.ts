export interface Resume {
  id: string;
  name: string;
  email: string;
  phone?: string;
  location?: string;
  website?: string;
  linkedin?: string;
  github?: string;
  parsed_date: string;
  summary?: string;
  skills: string[];
  education: Education[];
  experience: Experience[];
}

export interface Education {
  degree: string;
  institution: string;
  year: string;
  description?: string;
}

export interface Experience {
  title: string;
  company: string;
  location?: string;
  duration: string;
  description: string;
}

export interface ParsedResumeResponse {
  id: string;
  name: string;
  email: string;
  phone?: string;
  location?: string;
  skills: string[];
  education: Education[];
  experience: Experience[];
  raw_text?: string;
}