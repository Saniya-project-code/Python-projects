export const mockStats = {
  totalResumes: 256,
  parsedToday: 12,
  totalCandidates: 245,
  successRate: 96,
};

export const mockActivities = [
  {
    id: 1,
    type: 'upload',
    description: 'John Smith uploaded 3 new resumes',
    timestamp: '10 minutes ago',
  },
  {
    id: 2,
    type: 'parse',
    description: 'Resume parsing completed for "senior_developer_resume.pdf"',
    timestamp: '25 minutes ago',
  },
  {
    id: 3,
    type: 'search',
    description: 'You searched for "React developers with 5+ years experience"',
    timestamp: '1 hour ago',
  },
  {
    id: 4,
    type: 'export',
    description: 'You exported 15 resumes to CSV format',
    timestamp: '3 hours ago',
  },
  {
    id: 5,
    type: 'parse',
    description: 'Resume parsing failed for "corrupt_file.doc"',
    timestamp: '5 hours ago',
  },
];

export const mockResumes = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john.smith@example.com',
    phone: '+1 (555) 123-4567',
    location: 'San Francisco, CA',
    website: 'https://johnsmith.dev',
    linkedin: 'https://linkedin.com/in/johnsmith',
    github: 'https://github.com/johnsmith',
    parsed_date: '2023-10-15T14:30:00Z',
    summary: 'Senior software engineer with 8+ years of experience in full-stack development, specializing in React, Node.js, and AWS. Passionate about creating scalable and performant web applications.',
    skills: ['React', 'TypeScript', 'Node.js', 'AWS', 'GraphQL', 'Docker', 'Kubernetes', 'MongoDB', 'PostgreSQL'],
    education: [
      {
        degree: 'Master of Computer Science',
        institution: 'Stanford University',
        year: '2015-2017',
        description: 'Specialized in Artificial Intelligence and Machine Learning'
      },
      {
        degree: 'Bachelor of Science in Computer Engineering',
        institution: 'MIT',
        year: '2011-2015',
        description: 'GPA: 3.8/4.0. Relevant coursework: Data Structures, Algorithms, Software Engineering'
      }
    ],
    experience: [
      {
        title: 'Senior Software Engineer',
        company: 'Tech Innovations Inc.',
        location: 'San Francisco, CA',
        duration: 'Jan 2020 - Present',
        description: 'Lead a team of 5 engineers in developing and maintaining a high-traffic e-commerce platform. Implemented microservices architecture, reducing system latency by 40%. Mentored junior developers and conducted code reviews.'
      },
      {
        title: 'Software Engineer',
        company: 'DataViz Corp',
        location: 'Seattle, WA',
        duration: 'Aug 2017 - Dec 2019',
        description: 'Developed data visualization components using React and D3.js. Optimized frontend performance, improving page load times by 60%. Collaborated with product managers and designers to implement new features.'
      },
      {
        title: 'Software Development Intern',
        company: 'Google',
        location: 'Mountain View, CA',
        duration: 'May 2016 - Aug 2016',
        description: 'Worked on the Gmail team to develop new features for the web client. Implemented responsive design improvements and fixed critical bugs.'
      }
    ]
  },
  {
    id: '2',
    name: 'Emily Johnson',
    email: 'emily.johnson@example.com',
    phone: '+1 (555) 987-6543',
    location: 'New York, NY',
    linkedin: 'https://linkedin.com/in/emilyjohnson',
    parsed_date: '2023-10-14T10:15:00Z',
    skills: ['Python', 'Data Science', 'Machine Learning', 'TensorFlow', 'PyTorch', 'SQL', 'Data Visualization', 'R'],
    education: [
      {
        degree: 'PhD in Computer Science',
        institution: 'Columbia University',
        year: '2018-2022',
      },
      {
        degree: 'Master of Science in Data Science',
        institution: 'NYU',
        year: '2016-2018',
      }
    ],
    experience: [
      {
        title: 'Senior Data Scientist',
        company: 'FinTech Solutions',
        location: 'New York, NY',
        duration: 'Jun 2022 - Present',
        description: 'Leading machine learning initiatives for fraud detection. Developed and deployed models that increased fraud detection by 35% while reducing false positives by 20%.'
      },
      {
        title: 'Data Scientist',
        company: 'AI Research Lab',
        location: 'Boston, MA',
        duration: 'Sep 2018 - May 2022',
        description: 'Conducted research in natural language processing and sentiment analysis. Published 3 papers in leading AI conferences. Developed an NLP model for customer feedback analysis.'
      }
    ]
  },
  {
    id: '3',
    name: 'Michael Chen',
    email: 'michael.chen@example.com',
    location: 'Austin, TX',
    github: 'https://github.com/mchen',
    parsed_date: '2023-10-13T09:45:00Z',
    skills: ['JavaScript', 'React', 'Vue.js', 'CSS', 'SASS', 'Webpack', 'UI/UX', 'Figma'],
    education: [
      {
        degree: 'Bachelor of Fine Arts in Design',
        institution: 'Rhode Island School of Design',
        year: '2014-2018',
      }
    ],
    experience: [
      {
        title: 'Senior Frontend Engineer',
        company: 'Creative Digital Agency',
        location: 'Austin, TX',
        duration: 'Mar 2021 - Present',
        description: 'Leading the frontend team in creating responsive and accessible web applications. Implemented component libraries and design systems that improved development efficiency by 30%.'
      },
      {
        title: 'UI Developer',
        company: 'Tech Startup Inc.',
        location: 'San Diego, CA',
        duration: 'Jul 2018 - Feb 2021',
        description: 'Designed and developed user interfaces for mobile and web applications. Collaborated with UX designers to implement pixel-perfect designs and animations.'
      }
    ]
  },
  {
    id: '4',
    name: 'Sarah Miller',
    email: 'sarah.miller@example.com',
    phone: '+1 (555) 234-5678',
    location: 'Chicago, IL',
    linkedin: 'https://linkedin.com/in/sarahmiller',
    parsed_date: '2023-10-12T16:20:00Z',
    skills: ['Product Management', 'Agile', 'Scrum', 'JIRA', 'User Research', 'Market Analysis', 'SQL', 'Tableau'],
    education: [
      {
        degree: 'MBA',
        institution: 'University of Chicago Booth School of Business',
        year: '2015-2017',
      },
      {
        degree: 'Bachelor of Science in Business',
        institution: 'Indiana University',
        year: '2011-2015',
      }
    ],
    experience: [
      {
        title: 'Senior Product Manager',
        company: 'Enterprise Solutions',
        location: 'Chicago, IL',
        duration: 'Aug 2020 - Present',
        description: 'Leading product strategy and roadmap for enterprise SaaS solutions. Collaborated with engineering and design teams to launch 4 major features that increased user engagement by 45%.'
      },
      {
        title: 'Product Manager',
        company: 'Tech Innovations',
        location: 'Chicago, IL',
        duration: 'Jun 2017 - Jul 2020',
        description: 'Managed the product lifecycle from conception to launch for a mobile application with 500K+ users. Conducted user research and market analysis to identify product opportunities.'
      }
    ]
  },
  {
    id: '5',
    name: 'David Rodriguez',
    email: 'david.rodriguez@example.com',
    phone: '+1 (555) 876-5432',
    location: 'Miami, FL',
    github: 'https://github.com/drodriguez',
    parsed_date: '2023-10-11T11:10:00Z',
    skills: ['Java', 'Spring Boot', 'Microservices', 'Kubernetes', 'Docker', 'CI/CD', 'AWS', 'Maven', 'JUnit'],
    education: [
      {
        degree: 'Master of Science in Software Engineering',
        institution: 'Georgia Tech',
        year: '2016-2018',
      },
      {
        degree: 'Bachelor of Science in Computer Science',
        institution: 'University of Florida',
        year: '2012-2016',
      }
    ],
    experience: [
      {
        title: 'Lead Backend Engineer',
        company: 'Financial Services Inc.',
        location: 'Miami, FL',
        duration: 'Feb 2021 - Present',
        description: 'Architected and implemented scalable microservices for a financial platform processing $10M+ transactions daily. Led the migration from monolith to microservices architecture.'
      },
      {
        title: 'Backend Developer',
        company: 'E-commerce Platform',
        location: 'Atlanta, GA',
        duration: 'Sep 2018 - Jan 2021',
        description: 'Developed and maintained Java-based backend services. Improved system performance by 60% through database optimization and caching strategies.'
      },
      {
        title: 'Software Engineer Intern',
        company: 'Tech Giants',
        location: 'Seattle, WA',
        duration: 'May 2017 - Aug 2017',
        description: 'Worked on cloud infrastructure team to develop CI/CD pipelines and automate deployment processes.'
      }
    ]
  },
];