import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Download, 
  Trash2, 
  FileText, 
  Calendar, 
  Mail, 
  Phone, 
  GraduationCap, 
  Briefcase,
  MapPin,
  Globe,
  Github,
  Linkedin,
  Loader2
} from 'lucide-react';
import { mockResumes } from '../utils/mockData';
import { formatDate } from '../utils/formatters';

interface Resume {
  id: string;
  name: string;
  email: string;
  phone?: string;
  location?: string;
  website?: string;
  linkedin?: string;
  github?: string;
  parsed_date: string;
  skills: string[];
  education: {
    degree: string;
    institution: string;
    year: string;
    description?: string;
  }[];
  experience: {
    title: string;
    company: string;
    location?: string;
    duration: string;
    description: string;
  }[];
  summary?: string;
}

const ResumeDetails = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [resume, setResume] = useState<Resume | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'original'>('overview');
  
  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      if (id) {
        const foundResume = mockResumes.find(r => r.id === id);
        if (foundResume) {
          setResume(foundResume);
        }
      }
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [id]);
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 text-primary-600 animate-spin" />
        <span className="ml-2 text-neutral-600">Loading resume details...</span>
      </div>
    );
  }
  
  if (!resume) {
    return (
      <div className="text-center py-12">
        <p className="text-xl font-medium text-neutral-700">Resume not found</p>
        <button 
          onClick={() => navigate('/resumes')}
          className="mt-4 text-primary-600 hover:text-primary-800 inline-flex items-center"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to resumes
        </button>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => navigate('/resumes')}
            className="p-1.5 rounded-full hover:bg-neutral-100 text-neutral-500 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-2xl font-bold text-neutral-900">{resume.name}</h1>
        </div>
        
        <div className="flex space-x-2">
          <button className="flex items-center px-3 py-1.5 bg-white border border-neutral-300 rounded-lg text-neutral-700 hover:bg-neutral-50 transition-colors">
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
          <button className="flex items-center px-3 py-1.5 bg-white border border-error-300 rounded-lg text-error-700 hover:bg-error-50 transition-colors">
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </button>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-neutral-200">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-1 font-medium text-sm border-b-2 transition-colors ${
              activeTab === 'overview' 
                ? 'border-primary-600 text-primary-600' 
                : 'border-transparent text-neutral-500 hover:text-neutral-700 hover:border-neutral-300'
            }`}
          >
            Parsed Data
          </button>
          <button
            onClick={() => setActiveTab('original')}
            className={`py-3 px-1 font-medium text-sm border-b-2 transition-colors ${
              activeTab === 'original' 
                ? 'border-primary-600 text-primary-600' 
                : 'border-transparent text-neutral-500 hover:text-neutral-700 hover:border-neutral-300'
            }`}
          >
            Original Document
          </button>
        </nav>
      </div>
      
      {activeTab === 'overview' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column - Basic Info */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden">
              <div className="p-4 border-b border-neutral-200">
                <h3 className="font-medium text-neutral-900">Basic Information</h3>
              </div>
              <div className="p-4 space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="p-1.5 rounded-full bg-primary-100 text-primary-600">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Parsed on</p>
                    <p className="font-medium text-neutral-800 flex items-center">
                      <Calendar className="h-4 w-4 mr-1.5 text-neutral-400" />
                      {formatDate(resume.parsed_date)}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="p-1.5 rounded-full bg-primary-100 text-primary-600">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Email</p>
                    <a 
                      href={`mailto:${resume.email}`} 
                      className="font-medium text-primary-600 hover:underline"
                    >
                      {resume.email}
                    </a>
                  </div>
                </div>
                
                {resume.phone && (
                  <div className="flex items-start space-x-3">
                    <div className="p-1.5 rounded-full bg-primary-100 text-primary-600">
                      <Phone className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm text-neutral-500">Phone</p>
                      <a 
                        href={`tel:${resume.phone}`} 
                        className="font-medium text-neutral-800 hover:text-primary-600"
                      >
                        {resume.phone}
                      </a>
                    </div>
                  </div>
                )}
                
                {resume.location && (
                  <div className="flex items-start space-x-3">
                    <div className="p-1.5 rounded-full bg-primary-100 text-primary-600">
                      <MapPin className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm text-neutral-500">Location</p>
                      <p className="font-medium text-neutral-800">
                        {resume.location}
                      </p>
                    </div>
                  </div>
                )}
                
                {/* Links */}
                {(resume.website || resume.linkedin || resume.github) && (
                  <div className="border-t border-neutral-200 pt-4 mt-4">
                    <h4 className="text-sm font-medium text-neutral-600 mb-3">Links</h4>
                    
                    {resume.website && (
                      <a 
                        href={resume.website}
                        target="_blank"
                        rel="noopener noreferrer" 
                        className="flex items-center mb-2 text-neutral-700 hover:text-primary-600 group"
                      >
                        <Globe className="h-4 w-4 mr-2 text-neutral-400 group-hover:text-primary-500" />
                        <span className="text-sm group-hover:underline">Personal Website</span>
                      </a>
                    )}
                    
                    {resume.linkedin && (
                      <a 
                        href={resume.linkedin}
                        target="_blank"
                        rel="noopener noreferrer" 
                        className="flex items-center mb-2 text-neutral-700 hover:text-primary-600 group"
                      >
                        <Linkedin className="h-4 w-4 mr-2 text-neutral-400 group-hover:text-primary-500" />
                        <span className="text-sm group-hover:underline">LinkedIn Profile</span>
                      </a>
                    )}
                    
                    {resume.github && (
                      <a 
                        href={resume.github}
                        target="_blank"
                        rel="noopener noreferrer" 
                        className="flex items-center text-neutral-700 hover:text-primary-600 group"
                      >
                        <Github className="h-4 w-4 mr-2 text-neutral-400 group-hover:text-primary-500" />
                        <span className="text-sm group-hover:underline">GitHub Profile</span>
                      </a>
                    )}
                  </div>
                )}
              </div>
            </div>
            
            {/* Skills */}
            <div className="bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden">
              <div className="p-4 border-b border-neutral-200">
                <h3 className="font-medium text-neutral-900">Skills</h3>
              </div>
              <div className="p-4">
                <div className="flex flex-wrap gap-1.5">
                  {resume.skills.map((skill, index) => (
                    <span 
                      key={index}
                      className="px-2.5 py-1 bg-primary-50 text-primary-700 text-sm rounded-full"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* Right column - Experience & Education */}
          <div className="lg:col-span-2 space-y-6">
            {/* Summary */}
            {resume.summary && (
              <div className="bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden">
                <div className="p-4 border-b border-neutral-200">
                  <h3 className="font-medium text-neutral-900">Professional Summary</h3>
                </div>
                <div className="p-4">
                  <p className="text-neutral-700">{resume.summary}</p>
                </div>
              </div>
            )}
            
            {/* Experience */}
            <div className="bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden">
              <div className="p-4 border-b border-neutral-200">
                <h3 className="font-medium text-neutral-900">Work Experience</h3>
              </div>
              <div className="divide-y divide-neutral-200">
                {resume.experience.map((exp, index) => (
                  <div key={index} className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium text-neutral-900">{exp.title}</h4>
                        <p className="text-neutral-700">{exp.company}</p>
                        {exp.location && (
                          <p className="text-sm text-neutral-500 flex items-center mt-1">
                            <MapPin className="h-3.5 w-3.5 mr-1 text-neutral-400" />
                            {exp.location}
                          </p>
                        )}
                      </div>
                      <div className="text-sm text-neutral-500 whitespace-nowrap">
                        {exp.duration}
                      </div>
                    </div>
                    <p className="mt-2 text-neutral-700 text-sm">{exp.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Education */}
            <div className="bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden">
              <div className="p-4 border-b border-neutral-200">
                <h3 className="font-medium text-neutral-900">Education</h3>
              </div>
              <div className="divide-y divide-neutral-200">
                {resume.education.map((edu, index) => (
                  <div key={index} className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium text-neutral-900">{edu.degree}</h4>
                        <p className="text-neutral-700">{edu.institution}</p>
                      </div>
                      <div className="text-sm text-neutral-500 whitespace-nowrap">
                        {edu.year}
                      </div>
                    </div>
                    {edu.description && (
                      <p className="mt-2 text-neutral-700 text-sm">{edu.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden">
          <div className="p-4 border-b border-neutral-200 flex justify-between">
            <h3 className="font-medium text-neutral-900">Original Document</h3>
            <button className="text-primary-600 hover:text-primary-800 text-sm font-medium flex items-center">
              <Download className="h-4 w-4 mr-1" />
              Download Original
            </button>
          </div>
          <div className="p-4">
            <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-8 flex flex-col items-center justify-center h-96">
              <FileText className="h-12 w-12 text-neutral-400 mb-4" />
              <p className="text-neutral-600 font-medium">Preview not available</p>
              <p className="text-neutral-500 text-sm mt-1">Download the original document to view it</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResumeDetails;