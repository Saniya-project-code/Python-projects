import { useState } from 'react';
import { Save, RefreshCw, Plus, Trash2 } from 'lucide-react';
import { toast } from 'react-toastify';

const Settings = () => {
  const [extractionFields, setExtractionFields] = useState([
    { id: 1, name: 'Name', enabled: true },
    { id: 2, name: 'Email', enabled: true },
    { id: 3, name: 'Phone', enabled: true },
    { id: 4, name: 'Address', enabled: true },
    { id: 5, name: 'Education', enabled: true },
    { id: 6, name: 'Experience', enabled: true },
    { id: 7, name: 'Skills', enabled: true },
    { id: 8, name: 'Languages', enabled: false },
    { id: 9, name: 'Projects', enabled: false },
    { id: 10, name: 'Certifications', enabled: false },
  ]);
  
  const [apiSettings, setApiSettings] = useState({
    apiKey: 'sk_test_abcdefg123456789',
    modelName: 'default',
    maxTokens: 1000,
    confidence: 0.75,
  });

  const [newField, setNewField] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  
  const toggleField = (id: number) => {
    setExtractionFields(prev => 
      prev.map(field => 
        field.id === id ? { ...field, enabled: !field.enabled } : field
      )
    );
  };
  
  const addNewField = () => {
    if (!newField.trim()) {
      toast.warning('Please enter a field name');
      return;
    }
    
    const exists = extractionFields.some(
      field => field.name.toLowerCase() === newField.toLowerCase()
    );
    
    if (exists) {
      toast.warning('This field already exists');
      return;
    }
    
    const newId = Math.max(...extractionFields.map(f => f.id)) + 1;
    setExtractionFields([
      ...extractionFields, 
      { id: newId, name: newField, enabled: true }
    ]);
    setNewField('');
    toast.success('New field added');
  };
  
  const removeField = (id: number) => {
    setExtractionFields(prev => prev.filter(field => field.id !== id));
    toast.success('Field removed');
  };
  
  const handleApiSettingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    setApiSettings(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value
    }));
  };
  
  const saveSettings = async () => {
    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast.success('Settings saved successfully');
    setIsSaving(false);
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-neutral-900">Settings</h1>
        <p className="text-neutral-500">Configure your resume parsing preferences</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Extraction Fields */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden">
          <div className="p-4 border-b border-neutral-200">
            <h3 className="font-medium text-neutral-900">Extraction Fields</h3>
            <p className="text-sm text-neutral-500 mt-1">
              Select which information to extract from resumes
            </p>
          </div>
          
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {extractionFields.map(field => (
                <div 
                  key={field.id} 
                  className="flex items-center justify-between p-3 border border-neutral-200 rounded-lg"
                >
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id={`field-${field.id}`}
                      checked={field.enabled}
                      onChange={() => toggleField(field.id)}
                      className="h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                    />
                    <label 
                      htmlFor={`field-${field.id}`}
                      className="ml-2 text-neutral-700"
                    >
                      {field.name}
                    </label>
                  </div>
                  
                  <button 
                    onClick={() => removeField(field.id)}
                    className="p-1 rounded-full hover:bg-neutral-100 text-neutral-400 hover:text-error-600 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
            
            <div className="mt-4 flex items-center space-x-2">
              <input
                type="text"
                value={newField}
                onChange={e => setNewField(e.target.value)}
                placeholder="Add custom field"
                className="flex-1 p-2 border border-neutral-300 rounded-lg text-sm focus:ring-primary-500 focus:border-primary-500"
              />
              <button
                onClick={addNewField}
                className="p-2 rounded-lg bg-primary-600 text-white hover:bg-primary-700 transition-colors"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
        
        {/* API Configuration */}
        <div className="lg:col-span-1 bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden">
          <div className="p-4 border-b border-neutral-200">
            <h3 className="font-medium text-neutral-900">API Configuration</h3>
            <p className="text-sm text-neutral-500 mt-1">
              Configure NLP model settings
            </p>
          </div>
          
          <div className="p-4 space-y-4">
            <div>
              <label htmlFor="apiKey" className="block text-sm font-medium text-neutral-700 mb-1">
                API Key
              </label>
              <input
                type="password"
                id="apiKey"
                name="apiKey"
                value={apiSettings.apiKey}
                onChange={handleApiSettingChange}
                className="w-full p-2 border border-neutral-300 rounded-lg text-sm focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
            
            <div>
              <label htmlFor="modelName" className="block text-sm font-medium text-neutral-700 mb-1">
                Model
              </label>
              <select
                id="modelName"
                name="modelName"
                value={apiSettings.modelName}
                onChange={handleApiSettingChange}
                className="w-full p-2 border border-neutral-300 rounded-lg text-sm focus:ring-primary-500 focus:border-primary-500"
              >
                <option value="default">Default</option>
                <option value="enhanced">Enhanced</option>
                <option value="specialized">Specialized</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="maxTokens" className="block text-sm font-medium text-neutral-700 mb-1">
                Max Tokens
              </label>
              <input
                type="number"
                id="maxTokens"
                name="maxTokens"
                value={apiSettings.maxTokens}
                onChange={handleApiSettingChange}
                min="100"
                max="5000"
                className="w-full p-2 border border-neutral-300 rounded-lg text-sm focus:ring-primary-500 focus:border-primary-500"
              />
              <p className="text-xs text-neutral-500 mt-1">
                Higher values allow processing longer documents but increase cost.
              </p>
            </div>
            
            <div>
              <label htmlFor="confidence" className="block text-sm font-medium text-neutral-700 mb-1">
                Confidence Threshold
              </label>
              <input
                type="range"
                id="confidence"
                name="confidence"
                value={apiSettings.confidence}
                onChange={handleApiSettingChange}
                min="0"
                max="1"
                step="0.01"
                className="w-full h-2 bg-neutral-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs text-neutral-500 mt-1">
                <span>Low Precision</span>
                <span>{(apiSettings.confidence * 100).toFixed(0)}%</span>
                <span>High Precision</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Action buttons */}
      <div className="flex items-center justify-end space-x-3">
        <button
          type="button"
          className="px-4 py-2 border border-neutral-300 rounded-lg text-neutral-700 hover:bg-neutral-50 transition-colors flex items-center"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Reset to Defaults
        </button>
        <button
          type="button"
          onClick={saveSettings}
          disabled={isSaving}
          className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors flex items-center disabled:bg-primary-400 disabled:cursor-not-allowed"
        >
          {isSaving ? (
            <>
              <Loader2 className="animate-spin h-4 w-4 mr-2" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default Settings;