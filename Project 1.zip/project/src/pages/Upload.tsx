import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileUp, X, Check, Loader2, File, AlertCircle } from 'lucide-react';
import { toast } from 'react-toastify';
import { parseResume } from '../services/resumeService';

const Upload = () => {
  const [files, setFiles] = useState<Array<{
    file: File;
    status: 'pending' | 'processing' | 'success' | 'error';
    error?: string;
  }>>([]);
  const [isUploading, setIsUploading] = useState(false);
  
  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      status: 'pending' as const,
    }));
    
    setFiles(prev => [...prev, ...newFiles]);
  }, []);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
    maxFiles: 10,
    maxSize: 10 * 1024 * 1024, // 10MB
  });

  const removeFile = (index: number) => {
    setFiles(prev => {
      const newFiles = [...prev];
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const handleUpload = async () => {
    if (files.length === 0) {
      toast.warning('Please add files to upload');
      return;
    }

    if (isUploading) return;

    setIsUploading(true);
    
    // Update status for all files to processing
    setFiles(prev => prev.map(f => ({ ...f, status: 'processing' as const })));

    // Process each file sequentially
    for (let i = 0; i < files.length; i++) {
      try {
        // Call API to parse resume
        await parseResume(files[i].file);
        
        // Update status for this file
        setFiles(prev => {
          const newFiles = [...prev];
          newFiles[i].status = 'success';
          return newFiles;
        });
        
        toast.success(`Successfully parsed: ${files[i].file.name}`);
      } catch (error) {
        // Update status for this file
        setFiles(prev => {
          const newFiles = [...prev];
          newFiles[i].status = 'error';
          newFiles[i].error = error instanceof Error ? error.message : 'Unknown error occurred';
          return newFiles;
        });
        
        toast.error(`Error parsing: ${files[i].file.name}`);
      }
    }

    setIsUploading(false);
  };
  
  const clearAllFiles = () => {
    setFiles([]);
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-neutral-900">Upload Resumes</h1>
        <p className="text-neutral-500">Upload PDF or DOC files to parse candidate information</p>
      </div>

      {/* Dropzone */}
      <div 
        {...getRootProps()} 
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all ${
          isDragActive 
            ? 'border-primary-500 bg-primary-50' 
            : 'border-neutral-300 hover:border-primary-400 hover:bg-neutral-50'
        }`}
      >
        <input {...getInputProps()} />
        
        <FileUp 
          className={`mx-auto h-12 w-12 mb-4 ${
            isDragActive ? 'text-primary-500' : 'text-neutral-400'
          }`} 
        />
        
        <p className="text-lg font-medium text-neutral-700">
          {isDragActive ? 'Drop the files here...' : 'Drag & drop resume files here'}
        </p>
        <p className="mt-2 text-neutral-500">
          or <span className="text-primary-600 font-medium">browse files</span>
        </p>
        <p className="mt-1 text-sm text-neutral-400">
          Supports: PDF, DOC, DOCX (max 10MB per file)
        </p>
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="bg-white border border-neutral-200 rounded-lg shadow-sm">
          <div className="flex justify-between items-center p-4 border-b border-neutral-200">
            <h3 className="font-medium text-neutral-800">Files ({files.length})</h3>
            <button 
              onClick={clearAllFiles}
              className="text-sm text-neutral-500 hover:text-error-600 transition-colors"
            >
              Clear all
            </button>
          </div>
          
          <ul className="divide-y divide-neutral-200">
            {files.map((fileObj, index) => (
              <li key={index} className="p-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <File className="h-5 w-5 text-neutral-400" />
                  <div className="flex flex-col">
                    <p className="text-sm font-medium text-neutral-800 truncate max-w-xs">
                      {fileObj.file.name}
                    </p>
                    <p className="text-xs text-neutral-500">
                      {(fileObj.file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {fileObj.status === 'pending' && (
                    <button
                      onClick={() => removeFile(index)}
                      className="p-1 rounded-full hover:bg-neutral-100 text-neutral-500 hover:text-error-600 transition-colors"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  )}
                  
                  {fileObj.status === 'processing' && (
                    <div className="text-primary-600">
                      <Loader2 className="h-5 w-5 animate-spin" />
                    </div>
                  )}
                  
                  {fileObj.status === 'success' && (
                    <div className="text-success-600">
                      <Check className="h-5 w-5" />
                    </div>
                  )}
                  
                  {fileObj.status === 'error' && (
                    <div className="text-error-600 flex items-center space-x-1">
                      <AlertCircle className="h-5 w-5" />
                      {fileObj.error && (
                        <span className="text-xs">{fileObj.error}</span>
                      )}
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ul>
          
          <div className="p-4 border-t border-neutral-200">
            <button
              onClick={handleUpload}
              disabled={isUploading || files.length === 0}
              className={`w-full py-2 px-4 rounded-lg font-medium flex items-center justify-center ${
                isUploading || files.length === 0
                  ? 'bg-neutral-200 text-neutral-500 cursor-not-allowed'
                  : 'bg-primary-600 text-white hover:bg-primary-700 transition-colors'
              }`}
            >
              {isUploading ? (
                <>
                  <Loader2 className="animate-spin h-5 w-5 mr-2" />
                  Processing...
                </>
              ) : (
                <>
                  <FileUp className="h-5 w-5 mr-2" />
                  Parse Resumes
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Upload;