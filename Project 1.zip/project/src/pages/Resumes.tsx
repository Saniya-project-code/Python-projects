import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  ChevronDown, 
  Download, 
  FileText, 
  Calendar, 
  Briefcase, 
  GraduationCap,
  Loader2
} from 'lucide-react';
import { mockResumes } from '../utils/mockData';
import { formatDate } from '../utils/formatters';

interface Resume {
  id: string;
  name: string;
  email: string;
  phone?: string;
  parsed_date: string;
  skills: string[];
  education: {
    degree: string;
    institution: string;
    year: string;
  }[];
  experience: {
    title: string;
    company: string;
    duration: string;
  }[];
}

const Resumes = () => {
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  
  // All available skills from all resumes
  const [availableSkills, setAvailableSkills] = useState<string[]>([]);
  
  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      setResumes(mockResumes);
      
      // Extract all unique skills
      const skills = new Set<string>();
      mockResumes.forEach(resume => {
        resume.skills.forEach(skill => skills.add(skill));
      });
      
      setAvailableSkills(Array.from(skills).sort());
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Filter resumes based on search term and selected skills
  const filteredResumes = resumes.filter(resume => {
    const matchesSearch = 
      searchTerm === '' || 
      resume.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resume.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resume.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
      
    const matchesSkills = 
      selectedSkills.length === 0 || 
      selectedSkills.every(skill => resume.skills.includes(skill));
      
    return matchesSearch && matchesSkills;
  });
  
  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };
  
  const exportData = () => {
    // In a real application, this would generate CSV or another format
    alert('Export functionality would be implemented here!');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Resumes</h1>
          <p className="text-neutral-500">Browse and search through parsed resumes</p>
        </div>
        
        <button
          onClick={exportData}
          className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
        >
          <Download className="h-4 w-4 mr-2" />
          Export
        </button>
      </div>
      
      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-5 w-5 text-neutral-400" />
          </div>
          <input
            type="search"
            className="block w-full p-2.5 pl-10 text-sm border border-neutral-300 rounded-lg bg-neutral-50 focus:ring-primary-500 focus:border-primary-500"
            placeholder="Search by name, email, or skills..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="relative">
          <button
            className="flex items-center px-4 py-2.5 bg-white border border-neutral-300 rounded-lg text-neutral-700 hover:bg-neutral-50 transition-colors"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filter by Skill
            <ChevronDown className="h-4 w-4 ml-2" />
          </button>
          
          {/* Skills dropdown */}
          <div className="absolute right-0 top-full mt-2 w-64 bg-white border border-neutral-200 rounded-lg shadow-lg z-10 p-3">
            <div className="max-h-60 overflow-y-auto">
              {availableSkills.map(skill => (
                <div key={skill} className="flex items-center py-1">
                  <input 
                    type="checkbox" 
                    id={`skill-${skill}`}
                    checked={selectedSkills.includes(skill)}
                    onChange={() => toggleSkill(skill)}
                    className="h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                  />
                  <label 
                    htmlFor={`skill-${skill}`} 
                    className="ml-2 text-sm text-neutral-700"
                  >
                    {skill}
                  </label>
                </div>
              ))}
            </div>
            
            {selectedSkills.length > 0 && (
              <div className="pt-2 mt-2 border-t border-neutral-200">
                <div className="flex flex-wrap gap-1">
                  {selectedSkills.map(skill => (
                    <span 
                      key={skill} 
                      className="px-2 py-1 bg-primary-100 text-primary-700 text-xs rounded-full flex items-center"
                    >
                      {skill}
                      <button 
                        onClick={() => toggleSkill(skill)}
                        className="ml-1 text-primary-700 hover:text-primary-900"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Resumes List */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 text-primary-600 animate-spin" />
          <span className="ml-2 text-neutral-600">Loading resumes...</span>
        </div>
      ) : filteredResumes.length > 0 ? (
        <div className="bg-white border border-neutral-200 rounded-lg shadow-sm overflow-hidden">
          <ul className="divide-y divide-neutral-200">
            {filteredResumes.map(resume => (
              <li key={resume.id} className="hover:bg-neutral-50 transition-colors">
                <Link to={`/resumes/${resume.id}`} className="block p-4">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 p-2 rounded-full bg-primary-100 text-primary-600">
                        <FileText className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-neutral-900">{resume.name}</h3>
                        <p className="text-sm text-neutral-600">{resume.email}</p>
                        {resume.phone && (
                          <p className="text-sm text-neutral-500">{resume.phone}</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex flex-col md:flex-row gap-4 mt-3 md:mt-0">
                      <div className="flex items-center text-sm text-neutral-500">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>Parsed: {formatDate(resume.parsed_date)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-3">
                    <div className="flex items-center space-x-2 text-sm text-neutral-600">
                      <GraduationCap className="h-4 w-4 text-secondary-600" />
                      <span>{resume.education[0]?.degree}, {resume.education[0]?.institution}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-neutral-600 mt-1">
                      <Briefcase className="h-4 w-4 text-accent-600" />
                      <span>{resume.experience[0]?.title}, {resume.experience[0]?.company}</span>
                    </div>
                  </div>
                  
                  {/* Skills tags */}
                  <div className="mt-3 flex flex-wrap gap-1">
                    {resume.skills.slice(0, 5).map((skill, index) => (
                      <span 
                        key={index} 
                        className="px-2 py-0.5 bg-primary-50 text-primary-700 text-xs rounded-full"
                      >
                        {skill}
                      </span>
                    ))}
                    {resume.skills.length > 5 && (
                      <span className="px-2 py-0.5 bg-neutral-50 text-neutral-600 text-xs rounded-full">
                        +{resume.skills.length - 5} more
                      </span>
                    )}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center bg-white border border-neutral-200 rounded-lg p-8">
          <div className="p-4 rounded-full bg-neutral-100 mb-4">
            <FileText className="h-8 w-8 text-neutral-400" />
          </div>
          <h3 className="text-lg font-medium text-neutral-900">No resumes found</h3>
          <p className="text-neutral-500 text-center mt-1">
            {searchTerm || selectedSkills.length > 0 
              ? 'Try adjusting your search or filters'
              : 'Upload resumes to get started'
            }
          </p>
          {(searchTerm || selectedSkills.length > 0) && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedSkills([]);
              }}
              className="mt-4 text-primary-600 hover:text-primary-800 text-sm font-medium"
            >
              Clear all filters
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default Resumes;