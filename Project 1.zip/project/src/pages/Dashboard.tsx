import { useState, useEffect } from 'react';
import { 
  Users, 
  FileCheck, 
  FileUp, 
  CheckCircle, 
  Clock, 
  BarChart3, 
  PieChart
} from 'lucide-react';
import StatsCard from '../components/dashboard/StatsCard';
import RecentActivity from '../components/dashboard/RecentActivity';
import SkillsDistribution from '../components/dashboard/SkillsDistribution';
import EducationLevels from '../components/dashboard/EducationLevels';
import { mockStats, mockActivities } from '../utils/mockData';

const Dashboard = () => {
  const [stats, setStats] = useState(mockStats);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-neutral-900">Dashboard</h1>
        <p className="text-neutral-500">Overview of your resume parsing activities</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Total Resumes" 
          value={stats.totalResumes} 
          icon={<FileCheck className="h-6 w-6 text-primary-500" />}
          trend={+12}
          loading={loading}
        />
        <StatsCard 
          title="Parsed Today" 
          value={stats.parsedToday} 
          icon={<FileUp className="h-6 w-6 text-secondary-500" />}
          trend={+5}
          loading={loading}
        />
        <StatsCard 
          title="Candidates" 
          value={stats.totalCandidates} 
          icon={<Users className="h-6 w-6 text-accent-500" />}
          trend={+8}
          loading={loading}
        />
        <StatsCard 
          title="Success Rate" 
          value={`${stats.successRate}%`} 
          icon={<CheckCircle className="h-6 w-6 text-success-500" />}
          trend={+2.5}
          loading={loading}
        />
      </div>

      {/* Charts & Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-sm p-4 border border-neutral-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-neutral-900 flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary-500" />
                Skills Distribution
              </h2>
            </div>
            <SkillsDistribution loading={loading} />
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4 border border-neutral-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-neutral-900 flex items-center gap-2">
                <PieChart className="h-5 w-5 text-secondary-500" />
                Education Levels
              </h2>
            </div>
            <EducationLevels loading={loading} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-4 border border-neutral-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-neutral-900 flex items-center gap-2">
              <Clock className="h-5 w-5 text-accent-500" />
              Recent Activity
            </h2>
          </div>
          <RecentActivity activities={mockActivities} loading={loading} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;