# Automated Resume Parser

A professional application for extracting and categorizing information from resumes (PDFs/Docs) using advanced NLP techniques.

## Features

- Upload and process PDF/DOC/DOCX resumes
- Extract key information including:
  - Contact details (name, email, phone)
  - Skills and technologies
  - Education history
  - Work experience
- Search and filter candidates by skills, education, and experience
- Visual dashboard with analytics
- Export parsed data to various formats

## Technology Stack

- **Frontend**: React, TypeScript, Tailwind CSS
- **Backend**: Python, Flask
- **NLP Processing**: spaCy, PDFPlumber
- **Database**: PostgreSQL

## Project Structure

The project is organized into a frontend React application and a Python backend service:

- `/src`: React frontend application
  - `/components`: Reusable UI components
  - `/pages`: Application pages/routes
  - `/services`: API service functions
  - `/utils`: Utility functions and helpers
  - `/types`: TypeScript type definitions

- `/backend`: Python Flask application (to be implemented)
  - `/api`: API routes and handlers
  - `/parser`: Resume parsing logic using NLP
  - `/database`: Database models and connections
  - `/utils`: Utility functions

## Getting Started

### Prerequisites

- Node.js
- Python 3.8+
- PostgreSQL

### Installation

1. Clone the repository
2. Install frontend dependencies:
   ```
   npm install
   ```
3. Install backend dependencies:
   ```
   cd backend
   pip install -r requirements.txt
   ```

### Running the Application

1. Start the frontend development server:
   ```
   npm run dev
   ```

2. Start the backend server:
   ```
   cd backend
   python app.py
   ```

## Future Enhancements

- ML model training for improved accuracy
- Support for additional file formats
- Advanced candidate matching algorithms
- Email notifications
- Integration with job boards and ATS systems

## License

MIT License