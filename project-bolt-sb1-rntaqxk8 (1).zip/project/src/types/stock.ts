export interface StockData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  currency: string;
}

export interface StockDetails extends StockData {
  marketCap: number;
  peRatio: number | null;
  volume: number;
  avgVolume: number;
  high52Week: number;
  low52Week: number;
  dividendYield: number | null;
  beta: number | null;
  description: string;
}

export interface ChartData {
  timestamp: number;
  price: number;
}

export interface StockChartData {
  symbol: string;
  data: ChartData[];
  timeframe: TimeFrame;
}

export type TimeFrame = '1D' | '1W' | '1M' | '3M' | '1Y';

export interface MarketIndex {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
}