import axios from 'axios';
import { ChartData, MarketIndex, StockData, StockDetails, TimeFrame } from '../types/stock';

// Mock data (replace with actual API calls in production)
const MOCK_STOCKS: StockData[] = [
  {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    price: 182.63,
    change: 1.25,
    changePercent: 0.69,
    currency: 'USD'
  },
  {
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    price: 413.64,
    change: -2.35,
    changePercent: -0.56,
    currency: 'USD'
  },
  {
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    price: 174.45,
    change: 3.12,
    changePercent: 1.82,
    currency: 'USD'
  },
  {
    symbol: 'AMZN',
    name: 'Amazon.com Inc.',
    price: 182.81,
    change: -0.94,
    changePercent: -0.51,
    currency: 'USD'
  },
  {
    symbol: 'TSLA',
    name: 'Tesla, Inc.',
    price: 194.05,
    change: 5.32,
    changePercent: 2.82,
    currency: 'USD'
  }
];

const MOCK_INDICES: MarketIndex[] = [
  {
    symbol: '^DJI',
    name: 'Dow Jones',
    price: 38.803,
    change: 123.45,
    changePercent: 0.32
  },
  {
    symbol: '^GSPC',
    name: 'S&P 500',
    price: 5137.08,
    change: 26.41,
    changePercent: 0.52
  },
  {
    symbol: '^IXIC',
    name: 'NASDAQ',
    price: 16274.09,
    change: -14.12,
    changePercent: -0.09
  }
];

// Generate mock chart data
const generateMockChartData = (
  basePrice: number, 
  timeframe: TimeFrame,
  volatility = 0.01
): ChartData[] => {
  const data: ChartData[] = [];
  const now = new Date();
  let points = 0;
  let timeStep = 0;
  
  switch (timeframe) {
    case '1D':
      points = 78; // 6.5 hours (market hours) in 5 min intervals
      timeStep = 5 * 60 * 1000; // 5 minutes
      now.setHours(9, 30, 0, 0); // Market open
      break;
    case '1W':
      points = 5 * 78; // 5 days with 78 points per day
      timeStep = 5 * 60 * 1000; // 5 minutes
      now.setDate(now.getDate() - 5);
      now.setHours(9, 30, 0, 0);
      break;
    case '1M':
      points = 23; // ~23 trading days in a month
      timeStep = 24 * 60 * 60 * 1000; // 1 day
      now.setMonth(now.getMonth() - 1);
      break;
    case '3M':
      points = 66; // ~66 trading days in 3 months
      timeStep = 24 * 60 * 60 * 1000; // 1 day
      now.setMonth(now.getMonth() - 3);
      break;
    case '1Y':
      points = 12; // 12 months
      timeStep = 30 * 24 * 60 * 60 * 1000; // ~1 month
      now.setFullYear(now.getFullYear() - 1);
      break;
  }

  let price = basePrice;
  let timestamp = now.getTime();

  for (let i = 0; i < points; i++) {
    // Random price movement with trend bias
    const change = price * (Math.random() * volatility * 2 - volatility) + (i / points * 0.1 * basePrice);
    price += change;
    
    data.push({
      timestamp,
      price: Math.max(0.01, price) // Ensure price doesn't go below 0.01
    });
    
    timestamp += timeStep;
  }

  return data;
};

// Get trending stocks
export const getTrendingStocks = async (): Promise<StockData[]> => {
  // In a real app, this would fetch from an API
  return Promise.resolve(MOCK_STOCKS);
};

// Get market indices
export const getMarketIndices = async (): Promise<MarketIndex[]> => {
  // In a real app, this would fetch from an API
  return Promise.resolve(MOCK_INDICES);
};

// Search stocks by query
export const searchStocks = async (query: string): Promise<StockData[]> => {
  // In a real app, this would fetch from an API
  const filteredStocks = MOCK_STOCKS.filter(
    stock => stock.symbol.toLowerCase().includes(query.toLowerCase()) || 
             stock.name.toLowerCase().includes(query.toLowerCase())
  );
  return Promise.resolve(filteredStocks);
};

// Get stock details
export const getStockDetails = async (symbol: string): Promise<StockDetails> => {
  // In a real app, this would fetch from an API
  const stock = MOCK_STOCKS.find(s => s.symbol === symbol);
  
  if (!stock) {
    throw new Error(`Stock with symbol ${symbol} not found`);
  }
  
  return Promise.resolve({
    ...stock,
    marketCap: stock.symbol === 'AAPL' ? 2.94e12 : 
               stock.symbol === 'MSFT' ? 3.08e12 : 
               stock.symbol === 'GOOGL' ? 2.28e12 : 
               stock.symbol === 'AMZN' ? 1.89e12 : 
               8.23e11,
    peRatio: stock.symbol === 'AAPL' ? 30.21 : 
             stock.symbol === 'MSFT' ? 35.67 : 
             stock.symbol === 'GOOGL' ? 25.43 : 
             stock.symbol === 'AMZN' ? 41.75 : 
             51.32,
    volume: Math.floor(Math.random() * 20000000) + 10000000,
    avgVolume: Math.floor(Math.random() * 30000000) + 15000000,
    high52Week: stock.price * 1.3,
    low52Week: stock.price * 0.7,
    dividendYield: stock.symbol === 'AAPL' ? 0.5 : 
                   stock.symbol === 'MSFT' ? 0.75 : 
                   stock.symbol === 'GOOGL' ? null : 
                   stock.symbol === 'AMZN' ? null : 
                   null,
    beta: stock.symbol === 'AAPL' ? 1.21 : 
          stock.symbol === 'MSFT' ? 0.95 : 
          stock.symbol === 'GOOGL' ? 1.06 : 
          stock.symbol === 'AMZN' ? 1.35 : 
          1.65,
    description: `This is a placeholder description for ${stock.name}. In a real application, this would contain a detailed company overview.`
  });
};

// Get stock chart data
export const getStockChartData = async (symbol: string, timeframe: TimeFrame): Promise<StockChartData> => {
  // In a real app, this would fetch from an API
  const stock = MOCK_STOCKS.find(s => s.symbol === symbol);
  
  if (!stock) {
    throw new Error(`Stock with symbol ${symbol} not found`);
  }
  
  return Promise.resolve({
    symbol,
    timeframe,
    data: generateMockChartData(stock.price, timeframe)
  });
};