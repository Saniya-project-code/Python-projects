import React from 'react';
import StockCard from './StockCard';
import { StockData } from '../types/stock';
import { useStockStore } from '../store/stockStore';

interface TrendingStocksProps {
  stocks: StockData[];
  isLoading: boolean;
  onSelectStock: (symbol: string) => void;
}

const TrendingStocks: React.FC<TrendingStocksProps> = ({ stocks, isLoading, onSelectStock }) => {
  const { watchlist } = useStockStore();
  
  if (isLoading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4 animate-pulse"></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="bg-gray-100 dark:bg-gray-700 h-32 rounded-xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
      <h3 className="font-semibold text-lg text-gray-900 dark:text-white mb-3 px-1">Trending Stocks</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {stocks.map((stock) => (
          <StockCard 
            key={stock.symbol} 
            stock={stock} 
            isWatchlisted={watchlist.some(item => item.symbol === stock.symbol)}
            onClick={() => onSelectStock(stock.symbol)}
          />
        ))}
      </div>
    </div>
  );
};

export default TrendingStocks;