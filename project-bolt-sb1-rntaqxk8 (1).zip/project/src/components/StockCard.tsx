import React from 'react';
import { ArrowDown, ArrowUp, Plus, Star, Trash } from 'lucide-react';
import { StockData } from '../types/stock';
import { formatCurrency, formatPercentage, getChangeColor } from '../utils/formatters';
import { useStockStore } from '../store/stockStore';

interface StockCardProps {
  stock: StockData;
  isWatchlisted?: boolean;
  onClick?: () => void;
}

const StockCard: React.FC<StockCardProps> = ({ stock, isWatchlisted = false, onClick }) => {
  const { addToWatchlist, removeFromWatchlist } = useStockStore();
  
  const handleWatchlistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isWatchlisted) {
      removeFromWatchlist(stock.symbol);
    } else {
      addToWatchlist(stock);
    }
  };
  
  return (
    <div 
      className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow 
                 border border-gray-100 dark:border-gray-700 cursor-pointer"
      onClick={onClick}
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-semibold text-lg text-gray-900 dark:text-white">{stock.symbol}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-[180px]">{stock.name}</p>
        </div>
        <button 
          className={`p-1.5 rounded-full ${isWatchlisted ? 'text-amber-500 hover:bg-amber-50 dark:hover:bg-gray-700' : 'text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
          onClick={handleWatchlistClick}
          aria-label={isWatchlisted ? "Remove from watchlist" : "Add to watchlist"}
        >
          {isWatchlisted ? <Star size={18} fill="currentColor" /> : <Plus size={18} />}
        </button>
      </div>
      
      <div className="mt-3 flex justify-between items-end">
        <div>
          <p className="text-xl font-bold text-gray-900 dark:text-white">
            {formatCurrency(stock.price, stock.currency)}
          </p>
        </div>
        <div className={`flex items-center ${getChangeColor(stock.change)}`}>
          {stock.change > 0 ? <ArrowUp size={16} /> : <ArrowDown size={16} />}
          <span className="ml-1 font-medium text-sm">
            {formatCurrency(Math.abs(stock.change), stock.currency)} ({formatPercentage(Math.abs(stock.changePercent))})
          </span>
        </div>
      </div>
    </div>
  );
};

export default StockCard;