import React from 'react';
import { MarketIndex } from '../types/stock';
import { formatPercentage, getChangeColor } from '../utils/formatters';
import { ArrowDown, ArrowUp } from 'lucide-react';

interface MarketOverviewProps {
  indices: MarketIndex[];
  isLoading: boolean;
}

const MarketOverview: React.FC<MarketOverviewProps> = ({ indices, isLoading }) => {
  if (isLoading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700 animate-pulse">
        <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4"></div>
        <div className="flex space-x-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex-1 h-14 bg-gray-200 dark:bg-gray-700 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
      <h2 className="font-semibold text-lg text-gray-900 dark:text-white mb-3">Market Overview</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {indices.map((index) => (
          <div 
            key={index.symbol}
            className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg flex flex-col"
          >
            <p className="text-sm font-medium text-gray-600 dark:text-gray-300">{index.name}</p>
            <div className="flex justify-between items-center mt-2">
              <p className="text-base font-semibold text-gray-900 dark:text-white">{index.price.toLocaleString()}</p>
              <div className={`flex items-center ${getChangeColor(index.change)}`}>
                {index.change > 0 ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
                <span className="ml-1 text-xs font-medium">
                  {formatPercentage(Math.abs(index.changePercent))}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MarketOverview;