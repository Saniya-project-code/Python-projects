import React, { useState, useRef, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { useStockStore } from '../store/stockStore';

interface StockSearchProps {
  onSelectStock: (symbol: string) => void;
}

const StockSearch: React.FC<StockSearchProps> = ({ onSelectStock }) => {
  const { searchQuery, searchResults, search, clearSearch } = useStockStore();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    search(query);
    setIsDropdownOpen(!!query);
  };
  
  const handleClear = () => {
    clearSearch();
    setIsDropdownOpen(false);
  };
  
  const handleSelectStock = (symbol: string) => {
    onSelectStock(symbol);
    setIsDropdownOpen(false);
  };
  
  return (
    <div className="relative" ref={searchRef}>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <Search size={18} className="text-gray-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-10 py-2.5 text-sm text-gray-900 border border-gray-200 rounded-lg bg-white 
                    focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:border-gray-600 
                    dark:text-white dark:focus:ring-blue-600"
          placeholder="Search stocks..."
          value={searchQuery}
          onChange={handleSearch}
          onFocus={() => setIsDropdownOpen(!!searchQuery)}
        />
        {searchQuery && (
          <button
            className="absolute inset-y-0 right-0 flex items-center pr-3"
            onClick={handleClear}
          >
            <X size={18} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200" />
          </button>
        )}
      </div>
      
      {isDropdownOpen && searchResults.length > 0 && (
        <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg max-h-80 overflow-y-auto">
          {searchResults.map((stock) => (
            <div
              key={stock.symbol}
              className="px-4 py-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 last:border-0"
              onClick={() => handleSelectStock(stock.symbol)}
            >
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">{stock.symbol}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{stock.name}</p>
                </div>
                <p className="text-gray-900 dark:text-white font-medium">${stock.price.toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {isDropdownOpen && searchQuery && searchResults.length === 0 && (
        <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg p-4">
          <p className="text-gray-500 dark:text-gray-400 text-center">No results found</p>
        </div>
      )}
    </div>
  );
};

export default StockSearch;