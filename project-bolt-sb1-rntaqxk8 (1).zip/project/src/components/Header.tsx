import React, { useState, useEffect } from 'react';
import { Sun, Moon, ChevronLeft } from 'lucide-react';
import StockSearch from './StockSearch';

interface HeaderProps {
  onSelectStock: (symbol: string) => void;
  isDetailsView: boolean;
  onBackClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onSelectStock, isDetailsView, onBackClick }) => {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark' || 
        (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });
  
  useEffect(() => {
    const root = window.document.documentElement;
    
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);
  
  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };
  
  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            {isDetailsView ? (
              <button 
                onClick={onBackClick}
                className="mr-3 p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                aria-label="Back"
              >
                <ChevronLeft size={20} />
              </button>
            ) : (
              <div className="flex items-center text-blue-600 dark:text-blue-400 mr-4">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="24" 
                  height="24" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="m2 12 5.25 5 1.5-1.5L5.5 12l3.25-3.5-1.5-1.5L2 12Z"></path>
                  <path d="m9 12 5.25 5 1.5-1.5L12.5 12l3.25-3.5-1.5-1.5L9 12Z"></path>
                  <path d="m16 12 5.25 5 1.5-1.5-3.25-3.5 3.25-3.5-1.5-1.5L16 12Z"></path>
                </svg>
                <h1 className="text-xl font-bold ml-2">MarketView</h1>
              </div>
            )}
            
            {!isDetailsView && (
              <div className="w-64 sm:w-80">
                <StockSearch onSelectStock={onSelectStock} />
              </div>
            )}
          </div>
          
          <button
            onClick={toggleTheme}
            className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;