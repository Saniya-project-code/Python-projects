import React, { useMemo } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartData,
  ChartOptions,
} from 'chart.js';
import { StockChartData, TimeFrame } from '../types/stock';
import { formatCurrency, formatDate, formatTime } from '../utils/formatters';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface StockChartProps {
  data: StockChartData | null;
  onTimeframeChange: (timeframe: TimeFrame) => void;
  selectedTimeframe: TimeFrame;
  currency: string;
}

const StockChart: React.FC<StockChartProps> = ({ 
  data, 
  onTimeframeChange, 
  selectedTimeframe,
  currency = 'USD'
}) => {
  const timeframes: TimeFrame[] = ['1D', '1W', '1M', '3M', '1Y'];
  
  const chartData = useMemo(() => {
    if (!data || !data.data.length) {
      return {
        labels: [],
        datasets: [
          {
            data: [],
            borderColor: '#0A84FF',
            backgroundColor: 'rgba(10, 132, 255, 0.1)',
            borderWidth: 2,
            pointRadius: 0,
            pointHoverRadius: 4,
            tension: 0.4,
            fill: true,
          },
        ],
      };
    }

    const isPositiveTrend = 
      data.data[data.data.length - 1].price >= data.data[0].price;
    
    const color = isPositiveTrend ? '#30D158' : '#FF453A';
    
    // Format labels based on timeframe
    const labels = data.data.map(point => {
      if (data.timeframe === '1D') {
        return formatTime(point.timestamp);
      } else {
        return formatDate(point.timestamp);
      }
    });

    return {
      labels,
      datasets: [
        {
          data: data.data.map(point => point.price),
          borderColor: color,
          backgroundColor: `${color}20`,
          borderWidth: 2,
          pointRadius: 0,
          pointHoverRadius: 4,
          tension: 0.4,
          fill: true,
        },
      ],
    };
  }, [data]);

  const chartOptions: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        callbacks: {
          label: (context) => {
            return formatCurrency(context.parsed.y, currency);
          },
        },
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        titleColor: '#1F2937',
        bodyColor: '#4B5563',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderWidth: 1,
        padding: 12,
        cornerRadius: 8,
        titleFont: {
          size: 14,
          weight: 'bold',
        },
        bodyFont: {
          size: 14,
        },
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          maxRotation: 0,
          color: '#9CA3AF',
          font: {
            size: 10,
          },
          maxTicksLimit: 6,
        },
      },
      y: {
        grid: {
          color: 'rgba(156, 163, 175, 0.1)',
        },
        ticks: {
          color: '#9CA3AF',
          font: {
            size: 10,
          },
          callback: (value) => {
            return formatCurrency(value as number, currency);
          },
        },
        position: 'right',
      },
    },
    interaction: {
      mode: 'index',
      intersect: false,
    },
    elements: {
      line: {
        tension: 0.4,
      },
    },
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold text-gray-900 dark:text-white">Price Chart</h3>
        <div className="flex space-x-1">
          {timeframes.map((timeframe) => (
            <button
              key={timeframe}
              className={`px-3 py-1 text-sm rounded-md ${
                selectedTimeframe === timeframe
                  ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
              } transition-colors duration-200`}
              onClick={() => onTimeframeChange(timeframe)}
            >
              {timeframe}
            </button>
          ))}
        </div>
      </div>
      
      <div className="h-64 md:h-80">
        {data ? (
          <Line data={chartData as ChartData<'line'>} options={chartOptions} />
        ) : (
          <div className="flex h-full items-center justify-center">
            <p className="text-gray-500 dark:text-gray-400">Loading chart data...</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default StockChart;