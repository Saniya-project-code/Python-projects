import React from 'react';
import { useStockStore } from '../store/stockStore';
import StockCard from './StockCard';

interface WatchlistSectionProps {
  onSelectStock: (symbol: string) => void;
}

const WatchlistSection: React.FC<WatchlistSectionProps> = ({ onSelectStock }) => {
  const { watchlist } = useStockStore();
  
  if (watchlist.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 text-center">
        <h3 className="font-semibold text-lg text-gray-900 dark:text-white mb-2">Your Watchlist</h3>
        <p className="text-gray-500 dark:text-gray-400 mb-4">
          Add stocks to your watchlist to track them here
        </p>
      </div>
    );
  }
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
      <h3 className="font-semibold text-lg text-gray-900 dark:text-white mb-3 px-1">Your Watchlist</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {watchlist.map((stock) => (
          <StockCard 
            key={stock.symbol} 
            stock={stock} 
            isWatchlisted={true}
            onClick={() => onSelectStock(stock.symbol)}
          />
        ))}
      </div>
    </div>
  );
};

export default WatchlistSection;