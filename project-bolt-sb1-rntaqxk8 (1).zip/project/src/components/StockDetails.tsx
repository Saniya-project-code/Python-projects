import React from 'react';
import { StockDetails } from '../types/stock';
import { formatCurrency, formatLargeNumber, formatPercentage, getChangeColor } from '../utils/formatters';
import { ArrowDown, ArrowUp } from 'lucide-react';

interface StockDetailsProps {
  stock: StockDetails;
}

const StockDetailsComponent: React.FC<StockDetailsProps> = ({ stock }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{stock.symbol}</h2>
          <p className="text-gray-500 dark:text-gray-400">{stock.name}</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            {formatCurrency(stock.price, stock.currency)}
          </p>
          <div className={`flex items-center justify-end ${getChangeColor(stock.change)}`}>
            {stock.change > 0 ? <ArrowUp size={16} /> : <ArrowDown size={16} />}
            <span className="ml-1 font-medium">
              {formatCurrency(Math.abs(stock.change), stock.currency)} ({formatPercentage(Math.abs(stock.changePercent))})
            </span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
          <p className="text-xs text-gray-500 dark:text-gray-400">Market Cap</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white mt-1">
            {formatLargeNumber(stock.marketCap)}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
          <p className="text-xs text-gray-500 dark:text-gray-400">P/E Ratio</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white mt-1">
            {stock.peRatio ? stock.peRatio.toFixed(2) : 'N/A'}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
          <p className="text-xs text-gray-500 dark:text-gray-400">Volume</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white mt-1">
            {formatLargeNumber(stock.volume)}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
          <p className="text-xs text-gray-500 dark:text-gray-400">Avg. Volume</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white mt-1">
            {formatLargeNumber(stock.avgVolume)}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
          <p className="text-xs text-gray-500 dark:text-gray-400">52W High</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white mt-1">
            {formatCurrency(stock.high52Week, stock.currency)}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
          <p className="text-xs text-gray-500 dark:text-gray-400">52W Low</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white mt-1">
            {formatCurrency(stock.low52Week, stock.currency)}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
          <p className="text-xs text-gray-500 dark:text-gray-400">Dividend Yield</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white mt-1">
            {stock.dividendYield ? `${stock.dividendYield.toFixed(2)}%` : 'N/A'}
          </p>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
          <p className="text-xs text-gray-500 dark:text-gray-400">Beta</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white mt-1">
            {stock.beta ? stock.beta.toFixed(2) : 'N/A'}
          </p>
        </div>
      </div>
      
      <div className="mt-6">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-2">About {stock.name}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300">
          {stock.description}
        </p>
      </div>
    </div>
  );
};

export default StockDetailsComponent;