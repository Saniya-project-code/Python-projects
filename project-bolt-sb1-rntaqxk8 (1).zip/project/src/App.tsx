import React, { useEffect, useState } from 'react';
import { useStockStore } from './store/stockStore';
import Layout from './components/Layout';
import MarketOverview from './components/MarketOverview';
import TrendingStocks from './components/TrendingStocks';
import WatchlistSection from './components/WatchlistSection';
import StockDetails from './components/StockDetails';
import StockChart from './components/StockChart';

function App() {
  const [isDetailsView, setIsDetailsView] = useState(false);
  
  const { 
    trending, 
    indices, 
    selectedStock, 
    chartData,
    selectedTimeframe,
    watchlist,
    isLoading, 
    error,
    fetchTrending, 
    fetchIndices, 
    fetchStockDetails, 
    setSelectedTimeframe
  } = useStockStore();
  
  useEffect(() => {
    fetchTrending();
    fetchIndices();
  }, [fetchTrending, fetchIndices]);
  
  const handleSelectStock = (symbol: string) => {
    fetchStockDetails(symbol);
    setIsDetailsView(true);
  };
  
  const handleBackClick = () => {
    setIsDetailsView(false);
  };
  
  return (
    <Layout 
      isDetailsView={isDetailsView} 
      onSelectStock={handleSelectStock} 
      onBackClick={handleBackClick}
    >
      {error && (
        <div className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 p-4 rounded-lg mb-6">
          <p>{error}</p>
        </div>
      )}
      
      {isDetailsView && selectedStock ? (
        <div className="space-y-6 animate-fade-in">
          <StockDetails stock={selectedStock} />
          <StockChart 
            data={chartData} 
            onTimeframeChange={setSelectedTimeframe}
            selectedTimeframe={selectedTimeframe}
            currency={selectedStock.currency}
          />
        </div>
      ) : (
        <div className="space-y-6 animate-fade-in">
          <MarketOverview indices={indices} isLoading={isLoading} />
          
          {watchlist.length > 0 && (
            <WatchlistSection onSelectStock={handleSelectStock} />
          )}
          
          <TrendingStocks 
            stocks={trending} 
            isLoading={isLoading}
            onSelectStock={handleSelectStock}
          />
        </div>
      )}
    </Layout>
  );
}

export default App;