import { create } from 'zustand';
import { StockData, StockDetails, StockChartData, TimeFrame, MarketIndex } from '../types/stock';
import { getMarketIndices, getStockChartData, getStockDetails, getTrendingStocks, searchStocks } from '../services/api';

interface StockState {
  trending: StockData[];
  watchlist: StockData[];
  indices: MarketIndex[];
  selectedStock: StockDetails | null;
  chartData: StockChartData | null;
  selectedTimeframe: TimeFrame;
  searchResults: StockData[];
  searchQuery: string;
  isLoading: boolean;
  error: string | null;

  // Actions
  fetchTrending: () => Promise<void>;
  fetchIndices: () => Promise<void>;
  fetchStockDetails: (symbol: string) => Promise<void>;
  fetchChartData: (symbol: string, timeframe: TimeFrame) => Promise<void>;
  setSelectedTimeframe: (timeframe: TimeFrame) => void;
  search: (query: string) => Promise<void>;
  addToWatchlist: (stock: StockData) => void;
  removeFromWatchlist: (symbol: string) => void;
  clearSearch: () => void;
}

export const useStockStore = create<StockState>((set, get) => ({
  trending: [],
  watchlist: [],
  indices: [],
  selectedStock: null,
  chartData: null,
  selectedTimeframe: '1D',
  searchResults: [],
  searchQuery: '',
  isLoading: false,
  error: null,

  fetchTrending: async () => {
    set({ isLoading: true, error: null });
    try {
      const trending = await getTrendingStocks();
      set({ trending, isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : 'Failed to fetch trending stocks', isLoading: false });
    }
  },

  fetchIndices: async () => {
    set({ isLoading: true, error: null });
    try {
      const indices = await getMarketIndices();
      set({ indices, isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : 'Failed to fetch market indices', isLoading: false });
    }
  },

  fetchStockDetails: async (symbol: string) => {
    set({ isLoading: true, error: null });
    try {
      const stockDetails = await getStockDetails(symbol);
      set({ selectedStock: stockDetails, isLoading: false });
      
      // Also fetch chart data with current timeframe
      const { selectedTimeframe } = get();
      get().fetchChartData(symbol, selectedTimeframe);
    } catch (err) {
      set({ error: err instanceof Error ? err.message : 'Failed to fetch stock details', isLoading: false });
    }
  },

  fetchChartData: async (symbol: string, timeframe: TimeFrame) => {
    set({ isLoading: true, error: null });
    try {
      const chartData = await getStockChartData(symbol, timeframe);
      set({ chartData, isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : 'Failed to fetch chart data', isLoading: false });
    }
  },

  setSelectedTimeframe: (timeframe: TimeFrame) => {
    set({ selectedTimeframe: timeframe });
    const { selectedStock } = get();
    if (selectedStock) {
      get().fetchChartData(selectedStock.symbol, timeframe);
    }
  },

  search: async (query: string) => {
    if (!query.trim()) {
      set({ searchResults: [], searchQuery: '' });
      return;
    }
    
    set({ isLoading: true, error: null, searchQuery: query });
    try {
      const results = await searchStocks(query);
      set({ searchResults: results, isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : 'Failed to search stocks', isLoading: false });
    }
  },

  addToWatchlist: (stock: StockData) => {
    const { watchlist } = get();
    if (!watchlist.some(item => item.symbol === stock.symbol)) {
      set({ watchlist: [...watchlist, stock] });
    }
  },

  removeFromWatchlist: (symbol: string) => {
    const { watchlist } = get();
    set({ watchlist: watchlist.filter(stock => stock.symbol !== symbol) });
  },

  clearSearch: () => {
    set({ searchResults: [], searchQuery: '' });
  }
}));